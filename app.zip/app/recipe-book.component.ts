import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
  templateUrl: 'recipe-book.component.html'
})
export class RecipeBookAppComponent {
}
